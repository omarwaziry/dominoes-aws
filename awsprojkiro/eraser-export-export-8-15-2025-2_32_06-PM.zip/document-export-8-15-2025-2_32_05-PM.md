# AWS Highly Available Web App Architecture



